package projectmanager.service;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;
import java.security.Key;
import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

@Component
public class JwtTokenProvider {
    private static final String SECRET_KEY = "MySuperSecretKeyForJWTGenerationWith256Bits";
    private static final long EXPIRATION_TIME = 60 * 60 * 1000; // 1시간

    private final Key key; // ✅ Key 객체로 변환

    // ✅ 로그아웃된 토큰을 저장하는 블랙리스트 (메모리 기반)
    private final ConcurrentHashMap<String, Boolean> blacklist = new ConcurrentHashMap<>();

    // ✅ 생성자에서 Key 객체 초기화
    public JwtTokenProvider() {
        this.key = Keys.hmacShaKeyFor(SECRET_KEY.getBytes()); // ✅ 비밀 키 변환
    }

    // ✅ JWT 생성 (Deprecated 메서드 사용 안 함)
    public String generateToken(String userId) {
        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + EXPIRATION_TIME);

        return Jwts.builder()
                .setSubject(userId)
                .setIssuedAt(now)
                .setExpiration(expiryDate)
                .signWith(key, SignatureAlgorithm.HS256) // ✅ Deprecated 메서드 제거
                .compact();
    }

    // ✅ JWT 검증 (Deprecated 메서드 사용 안 함)
    public boolean validateToken(String token) {
        try {
            if (blacklist.containsKey(token)) {
                return false; // 로그아웃된 토큰
            }
            Jwts.parserBuilder() // ✅ 새로운 방식 적용
                .setSigningKey(key) // ✅ Key 객체 사용
                .build()
                .parseClaimsJws(token);
            return true;
        } catch (JwtException | IllegalArgumentException e) {
            return false;
        }
    }

    // ✅ JWT에서 사용자 ID 추출 (Deprecated 메서드 사용 안 함)
    public String getUserIdFromToken(String token) {
        return Jwts.parserBuilder() // ✅ 새로운 방식 적용
                .setSigningKey(key) // ✅ Key 객체 사용
                .build()
                .parseClaimsJws(token)
                .getBody()
                .getSubject();
    }

    // ✅ 로그아웃 시 블랙리스트에 추가
    public void invalidateToken(String token) {
        blacklist.put(token, true);
    }
}

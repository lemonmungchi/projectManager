package projectmanager.infra;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import projectmanager.config.kafka.KafkaProcessor;

@Service
@Transactional
public class PolicyHandler {
    
    @StreamListener(KafkaProcessor.INPUT)
    public void whatever(@Payload String eventString) {}

    @StreamListener(
        value = KafkaProcessor.INPUT,
        condition = "headers['type']=='JwtDeleted'"
    )
    public void handleJwtDeleted(@Payload String token) {
        System.out.println("JWT Deleted: " + token);
    }
}

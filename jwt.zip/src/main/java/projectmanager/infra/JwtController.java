package projectmanager.infra;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import projectmanager.service.JwtTokenProvider;

@RestController
@RequestMapping("/jwt")
public class JwtController {
    private final JwtTokenProvider jwtTokenProvider;

    public JwtController(JwtTokenProvider jwtTokenProvider) {
        this.jwtTokenProvider = jwtTokenProvider;
    }

    // ✅ JWT 생성 API
    @PostMapping("/generate")
    public ResponseEntity<String> generateToken(@RequestBody String userId) {
        String token = jwtTokenProvider.generateToken(userId);
        return ResponseEntity.ok(token);
    }

    // ✅ JWT 검증 API
    @PostMapping("/validate")
    public ResponseEntity<Boolean> validateToken(@RequestBody String token) {
        boolean isValid = jwtTokenProvider.validateToken(token);
        return ResponseEntity.ok(isValid);
    }

    // ✅ JWT 무효화 API (로그아웃)
    @PostMapping("/invalidate")
    public ResponseEntity<String> invalidateToken(@RequestBody String token) {
        jwtTokenProvider.invalidateToken(token);
        return ResponseEntity.ok("Token invalidated successfully.");
    }
}
